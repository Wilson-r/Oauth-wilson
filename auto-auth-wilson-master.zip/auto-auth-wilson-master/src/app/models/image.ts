export interface IImage {
  url: string;
}

export class Image implements IImage {
  url: string;
}
