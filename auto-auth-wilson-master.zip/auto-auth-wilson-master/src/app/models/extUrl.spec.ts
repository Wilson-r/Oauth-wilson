import { ExtUrl } from './extUrl';

describe('ExtUrl', () => {
  it('should create an instance', () => {
    expect(new ExtUrl()).toBeTruthy();
  });
});
