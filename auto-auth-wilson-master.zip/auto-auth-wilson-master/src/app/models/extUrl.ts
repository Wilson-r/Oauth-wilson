export interface IExtUrl {
  spotify: string;
}

export class ExtUrl implements IExtUrl {
  spotify: string;
}
