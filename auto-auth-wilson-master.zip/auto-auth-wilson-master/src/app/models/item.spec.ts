import { Item } from './item';

describe('Track', () => {
  it('should create an instance', () => {
    expect(new Item()).toBeTruthy();
  });
});
